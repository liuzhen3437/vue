'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://39.105.170.120:8080"'
}
