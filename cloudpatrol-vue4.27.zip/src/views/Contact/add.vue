<template> 
  <line-detail :is-edit='false'></line-detail>
</template>
<script>
  import LineDetail from './components/detail'
  export default {
    name: 'add',
    components: { LineDetail }
  } 
</script>
<style>
</style>

