<template> 
  <line-detail :is-edit='true'></line-detail>
</template>
<script>
  import LineDetail from './components/detail'
  export default {
    name: 'update',
    components: { LineDetail }
  }
</script>
<style>
</style>


