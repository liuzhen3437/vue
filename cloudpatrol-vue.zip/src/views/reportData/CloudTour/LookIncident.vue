<template> 
  <address-detail :is-edit='true'></address-detail>
</template>
<script>
  import AddressDetail from './components/detail'
  export default {
    name: 'LookIncident',
    components: { AddressDetail }
  }
</script>
<style>
</style>

